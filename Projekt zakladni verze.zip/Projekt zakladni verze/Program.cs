﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjektEvidencePojistenych
{
    class Program
    {
        static void Main()
        {
            // Inicializace hlavního seznamu 
            List<Pojisteny> seznamPojistenych = new List<Pojisteny>();

            // Inicializace vyhledávače s prazdnym seznamem
            VyhledavacPojistenych vyhledavac = new VyhledavacPojistenych(seznamPojistenych);

            // Vytvoření a zobrazení menu
            Menu menu = new Menu(vyhledavac);
            menu.Zobrazit();
        }
    }
}