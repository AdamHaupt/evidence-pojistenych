﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjektEvidencePojistenych
{
    /// <summary>
    /// Třída reprezentující pojištěného
    /// </summary>
    public class Pojisteny
    {
        public string Jmeno { get; set; } // Jméno pojištěného
        public string Prijmeni { get; set; } // Příjmení pojištěného
        public int Vek { get; set; } // Věk pojištěného
        public int Predvolba { get; set; } // Předvolba telefonu
        public int TelCislo { get; set; } // Telefonní číslo pojištěného

        /// <summary>
        /// Vstup pro pojištěnou osobu
        /// </summary>
        /// <param name="jmeno">Jméno</param>
        /// <param name="prijmeni">Příjmení</param>
        /// <param name="vek">Věk</param>
        /// <param name="predvolba">Předvolba pro telefonní číslo</param>
        /// <param name="telCislo">Telefonní číslo</param>
        public Pojisteny(string jmeno, string prijmeni, int vek, int predvolba, int telCislo)
        {
            Jmeno = jmeno;
            Prijmeni = prijmeni;
            Vek = vek;
            Predvolba = predvolba;
            TelCislo = telCislo;
        }

        /// <summary>
        /// Metoda pro formátování telefonního čísla s mezerami
        /// </summary>
        /// <param name="telCislo">Telefonní číslo</param>
        /// <returns>Naformátované telefonní číslo</returns>
        private string FormatovaniTelCisla(int telCislo)
        {
            string telCisString = telCislo.ToString(); // Převod na řetězec
            string formatovani = ""; // Řetězec pro formátované číslo

            for (int i = 0; i < telCisString.Length; i++)
            {
                if (i > 0 && i % 3 == 0)
                {
                    formatovani += " "; // Vložení mezery po každých třech číslicích
                }
                formatovani += telCisString[i];
            }

            return formatovani; // Vrátí formátovaný řetězec
        }

        /// <summary>
        /// Vypíše údaje o pojištěném
        /// </summary>
        /// <returns>Celý výpis o pojištěném</returns>
        public override string ToString() =>
         $"Jméno: {Jmeno.PadRight(10)}\tPříjmení: {Prijmeni.PadRight(10)}\tVěk: {Vek.ToString().PadRight(5)}\tTel.číslo: +{Predvolba.ToString()} {FormatovaniTelCisla(TelCislo)}";
    }
}
