﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjektEvidencePojistenych
{
    /// <summary>
    /// Třída pro správu evidence pojištěných
    /// </summary>
    public class EvidencePojistencu
    {
        private VyhledavacPojistenych spravcePojistencu;

        public EvidencePojistencu(VyhledavacPojistenych spravcePojistencu)
        {
            this.spravcePojistencu = spravcePojistencu;
        }
        
        /// <summary>
        /// Přidá nového pojištěnce
        /// </summary>
        public void PridatNovehoPojisteneho()
        {
            
            string jmeno, prijmeni;
            int vek;
            int predvolba;
            int telCislo;

            // Kontrola jména na prázdný vstup
            do
            {
                Console.WriteLine("Zadejte jméno:");
                jmeno = Console.ReadLine();
                Console.WriteLine("");
            } while (string.IsNullOrWhiteSpace(jmeno)); // Pokračuje, pokud je jméno prázdné

            // Kontrola příjmení na prázdný vstup
            do
            {
                Console.WriteLine("Zadejte příjmení:");
                prijmeni = Console.ReadLine();
                Console.WriteLine("");
            } while (string.IsNullOrWhiteSpace(prijmeni)); // Pokračuje, pokud je příjmení prázdné

            // Získání věku
            Console.WriteLine("Zadejte věk: ");
            string vekVstup = Console.ReadLine();
            // Vstup pro věk s validací
            while (!int.TryParse(vekVstup, out vek))
            {
                Console.WriteLine("Neplatný vstup pro věk. Prosím zadejte platné celé číslo: ");
                vekVstup = Console.ReadLine();
            }
            Console.WriteLine("");

            // Vstup pro předvolbu s validací
            while (true)
            {
                Console.WriteLine("Zadejte předvolbu:");
                Console.Write("+");
                string input = Console.ReadLine().Trim();
                Console.WriteLine("");

                // Ověření předvolby
                if (int.TryParse(input, out predvolba) && input.Length == 3) // Zkontrolovat, že to má 3 číslice
                {
                    break; // Platný vstup, opustit smyčku
                }
                else
                {
                    Console.WriteLine("Předvolba musí být 3 číslice."); // Vypsání chyby
                }
            }
            
            while (true) // Vstup pro telefonní číslo s validací
            {
                Console.WriteLine("Zadejte telefonní číslo (9 místné):");
                string vstup = Console.ReadLine().Trim();
                Console.WriteLine("");

                string vstupBezMezer = vstup.Replace(" ", string.Empty); // Odstranit mezery pro validaci
                
                if (int.TryParse(vstupBezMezer, out telCislo) && vstupBezMezer.Length == 9)
                {
                    break; // Platný vstup, opustit smyčku
                }
                else
                {
                    if (vstupBezMezer.Length > 9)
                    {
                        Console.WriteLine("Číslo je moc dlouhé, zadejte prosím 9 místné číslo.");
                    }
                    else
                    {
                        Console.WriteLine("Číslo je moc krátké, zadejte prosím 9 místné číslo.");
                    }
                }
            }

            // Přidání nového pojištěného do vyhledávače
            spravcePojistencu.PridatZaznam(new Pojisteny(jmeno, prijmeni, vek, predvolba, telCislo));
            Console.WriteLine("Nový pojištěný byl přidán.");
            Console.ReadKey();
        }

        /// <summary>
        /// Získá všechny záznamy
        /// </summary>
        public void VypisVsechnyPojistene()
        {
            List<Pojisteny> vsechnyZaznamy = spravcePojistencu.ZiskatVsechnyZaznamy();

            Console.WriteLine("Všechny záznamy:");
            if (vsechnyZaznamy.Count > 0)
            {
                foreach (var osoba in vsechnyZaznamy)
                {
                    Console.WriteLine(osoba);
                }
            }
            else
            {
                Console.WriteLine("Žádné záznamy k dispozici.");
            }
            Console.ReadKey();
        }

        /// <summary>
        /// Vyhledává pojistného
        /// </summary>
        public void VyhledatPojisteneho()
        {
            Console.WriteLine("Zadejte jméno pro vyhledání:");
            string jmeno = Console.ReadLine().Trim();

            Console.WriteLine("Zadejte příjmení pro vyhledání:");
            string prijmeni = Console.ReadLine().Trim();

            List<Pojisteny> shodniPojistenci = spravcePojistencu.VyhledatPodleJmenaAPrijmeni(jmeno, prijmeni);

            if (shodniPojistenci.Count > 0)
            {
                Console.WriteLine("Shodné osoby:");
                foreach (var osoba in shodniPojistenci)
                {
                    Console.WriteLine(osoba);
                }
            }
            else
            {
                Console.WriteLine("Žádné shodné osoby nebyly nalezeny.");
            }
            Console.ReadKey();
        }

        /// <summary>
        /// Funkce pro testovací přidání osob
        /// </summary>
        public void TestPridaniOsob()
        {
            // Přidání testovacích záznamů přímo do hlavního seznamu
            spravcePojistencu.PridatZaznam(new Pojisteny("Jan", "Novak", 15, 420, 123456789));
            spravcePojistencu.PridatZaznam(new Pojisteny("Lucie", "Svobodova", 14, 420, 987654321));
            spravcePojistencu.PridatZaznam(new Pojisteny("Jan", "Dvorak", 8, 420, 111222333));
            spravcePojistencu.PridatZaznam(new Pojisteny("Eva", "Svobodova", 32, 420, 444555666));
            spravcePojistencu.PridatZaznam(new Pojisteny("David", "Hruby", 23, 420, 777888999));

            Console.WriteLine("Testovní uživatelé byli úspěšně přidáni.");
            Console.ReadKey();
        }
    }
    /// <summary>
    /// Třída obsahující funkce pro vyhledávání a zobrazování
    /// </summary>
    public class VyhledavacPojistenych
    {
        private List<Pojisteny> pojistenci;

        public VyhledavacPojistenych(List<Pojisteny> pojistenci)
        {
            this.pojistenci = pojistenci ?? throw new ArgumentNullException(nameof(pojistenci));
        }

        // 
        /// <summary>
        /// Přidá nový záznam
        /// </summary>
        /// <param name="novyZaznam">Seznam Nových Záynamů</param>
        public void PridatZaznam(Pojisteny novyZaznam)
        {
            pojistenci.Add(novyZaznam);
        }

        // Vyhledání osob podle jména a příjmení
        /// <summary>
        /// Vyhledá pojištěného podle jména příjmení
        /// </summary>
        /// <param name="jmeno">Jméno pojištěného</param>
        /// <param name="prijmeni">Příjmení pojištěného</param>
        /// <returns></returns>
        public List<Pojisteny> VyhledatPodleJmenaAPrijmeni(string jmeno, string prijmeni)
        {
            List<Pojisteny> shodniPojistenci = new List<Pojisteny>();

            foreach (var osoba in pojistenci)
            {
                if (osoba.Jmeno.Equals(jmeno, StringComparison.OrdinalIgnoreCase) &&
                    osoba.Prijmeni.Equals(prijmeni, StringComparison.OrdinalIgnoreCase))
                {
                    shodniPojistenci.Add(osoba);
                }
            }

            return shodniPojistenci;
        }

        /// <summary>
        /// Získá všechny záznamy
        /// </summary>
        /// <returns>Seznam dat v hlavním seznamu</returns>
        public List<Pojisteny> ZiskatVsechnyZaznamy()
        {
            return pojistenci;
        }
    }
}
