﻿using ProjektEvidencePojistenych;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjektEvidencePojistenych
{
    /// <summary>
    /// Třída pro správu uživatelského Uživatelského rozhranní
    /// </summary>
    public class Menu
    {
        private VyhledavacPojistenych vyhledavac;
        private EvidencePojistencu evidence;

        /// <summary>
        /// Vstup pro vyhledávání pojištěných
        /// </summary>
        /// <param name="vyhledavac">Vyhledávání</param>
        public Menu(VyhledavacPojistenych vyhledavac)
        {
            this.vyhledavac = vyhledavac;
            this.evidence = new EvidencePojistencu(vyhledavac);
        }

        /// <summary>
        /// Vykreslení menu s ovládáním
        /// </summary>
        public void Zobrazit()
        {
            bool pokracovat = true;
            while (pokracovat)
            {
                Console.Clear();
                Console.WriteLine("--------------------");
                Console.WriteLine("Evidence pojistenych");
                Console.WriteLine("--------------------");
                Console.WriteLine("");
                Console.WriteLine("Vyberte si akci:");
                Console.WriteLine("1 - Přidat nového pojištěného");
                Console.WriteLine("2 - Vypsat všechny pojištěné");
                Console.WriteLine("3 - Hledat pojištěného");
                Console.WriteLine("4 - Test přidání osob"); // Možnost pro testování
                Console.WriteLine("5 - Konec");

                char volba = Console.ReadKey().KeyChar;
                Console.WriteLine("");
                switch (volba)
                {
                    case '1':
                        evidence.PridatNovehoPojisteneho(); // Přidání pojistného
                        break;

                    case '2':
                        evidence.VypisVsechnyPojistene(); // Vypsání všech pojistných
                        break;

                    case '3':
                        evidence.VyhledatPojisteneho(); // Vyhledání pojistného
                        break;

                    case '4':
                        evidence.TestPridaniOsob(); // Test přidání osob
                        break;

                    case '5':
                        pokracovat = false; // Ukončení
                        break;

                    default:
                        Console.WriteLine("Neplatná volba, zkuste to znovu.");
                        break;
                }
            }
            Console.WriteLine("Děkuji za použití této aplikace. Vytvořil Adam Haupt."); // Zpráva po ukončení
            Console.ReadKey();
        }
    }
}
